# No seed data currently defined, but it would go here if you wanted it;
# this service is based on ActiveRecord, so use this file just like you
# would if it were inside a Rails app.
