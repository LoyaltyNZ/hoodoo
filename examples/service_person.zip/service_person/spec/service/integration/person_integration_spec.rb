require 'spec_helper'

RSpec.describe 'Person integration' do

  context '#create' do

    # Makes a POST call to create a Person resource and, if an expected
    # HTTP status code is seen, returns the parsed result (else fails the
    # expectation).
    #
    # +body_hash+::     Hash to convert to JSON and send in the POST request.
    # +expected_code+:: Optional expected HTTP response code as an Integer or
    #                   String. If omitted, defaults to 200.
    #
    def do_create( body_hash, expected_code = 200 )
      response = post(
        '/v1/people',
        JSON.generate( body_hash ),
        { 'CONTENT_TYPE' => 'application/json; charset=utf-8' }
      )

      expect( response.status.to_s ).to(
        eq( expected_code.to_s ),
        "Expected status code '#{ expected_code }', got '#{ response.status }' with body: #{ response.body }"
      )

      return JSON.parse( response.body )
    end

    it 'persists' do
      expect {
        do_create( 'name' => 'Harry' )
      }.to change { Person.count }.by( 1 )
    end

    it 'renders correctly' do
      result = do_create( 'name' => 'Harry' )

      expect( result[ 'kind' ] ).to eq( 'Person' )
      expect( result[ 'name' ] ).to eq( 'Harry'  )
    end

    it 'refuses creation without a name' do
      result = do_create( {}, 422 )

      expect( result[ 'errors' ].count ).to eq( 1 )
      expect( result[ 'errors' ][ 0 ][ 'code'      ] ).to eq( 'generic.required_field_missing' )
      expect( result[ 'errors' ][ 0 ][ 'reference' ] ).to eq( 'name'                           )
    end

    it 'refuses creation with a bad date of birth' do
      result = do_create( { 'name' => 'Jane', 'date_of_birth' => 'bad date' }, 422 )

      expect( result[ 'errors' ].count ).to eq( 1 )
      expect( result[ 'errors' ][ 0 ][ 'code'      ] ).to eq( 'generic.invalid_date' )
      expect( result[ 'errors' ][ 0 ][ 'reference' ] ).to eq( 'date_of_birth'        )
    end
  end

  context '#show' do
    before :each do
      @p1 = FactoryGirl.create( :person_with_dob )

      begin
        @p2 = FactoryGirl.create( :person_with_dob )
      end while @p1.name == @p2.name
    end

    # Makes a GET call to retrieve a Person resource and, if an expected
    # HTTP status code is seen, returns the parsed result (else fails the
    # expectation).
    #
    # +uuid+::          UUID to find.
    # +expected_code+:: Optional expected HTTP response code as an Integer or
    #                   String. If omitted, defaults to 200.
    #
    def do_show( uuid, expected_code = 200 )
      response = get(
        "/v1/people/#{ uuid }",
        nil,
        { 'CONTENT_TYPE' => 'application/json; charset=utf-8' }
      )

      expect( response.status.to_s ).to(
        eq( expected_code.to_s ),
        "Expected status code '#{ expected_code }', got '#{ response.status }' with body: #{ response.body }"
      )

      return JSON.parse( response.body )
    end

    it 'finds a person' do
      result = do_show( @p2.id )

      expect( result[ 'name'          ] ).to eq( @p2.name                  )
      expect( result[ 'date_of_birth' ] ).to eq( @p2.date_of_birth.iso8601 )
    end

    it '404s with a not-found UUID' do
      new_uuid = Hoodoo::UUID.generate()
      result   = do_show( new_uuid, 404 )

      expect( result[ 'errors' ].count ).to eq( 1 )
      expect( result[ 'errors' ][ 0 ][ 'code'      ] ).to eq( 'generic.not_found' )
      expect( result[ 'errors' ][ 0 ][ 'reference' ] ).to eq( new_uuid            )
    end
  end

  context '#list' do
    before :each do
      time   = Time.now - 10.minutes
      create = Proc.new do | attrs |
        time = time + 1.minute
        FactoryGirl.create( :person, attrs.merge( :created_at => time, :updated_at => time ) )
      end

      @p1 = create.call( :name => 'Alice One', :date_of_birth => '1975-03-01' )
      @p2 = create.call( :name => 'Alice Two', :date_of_birth => '1984-09-04' )
      @p3 = create.call( :name => 'Bob One',   :date_of_birth => '1975-11-23' )
      @p4 = create.call( :name => 'Bob Two',   :date_of_birth => '1956-02-01' )
    end

    # Makes a GET call to retrieve a list of Person resources and, if an
    # expected HTTP status code is seen, returns the parsed result (else
    # fails the expectation).
    #
    # +search+::        Optional search Hash; if omitted, defaults to empty.
    # +expected_code+:: Optional expected HTTP response code as an Integer or
    #                   String. If omitted, defaults to 200.
    #
    # The search Hash can use either String or Symbol keys or values.
    #
    def do_list( search = {}, expected_code = 200 )
      query = ''

      unless search.empty?
        encoded_search = URI.encode_www_form( search )
        query = '?' << URI.encode_www_form( 'search' => encoded_search )
      end

      response = get(
        "/v1/people#{ query }",
        nil,
        { 'CONTENT_TYPE' => 'application/json; charset=utf-8' }
      )

      expect( response.status.to_s ).to(
        eq( expected_code.to_s ),
        "Expected status code '#{ expected_code }', got '#{ response.status }' with body: #{ response.body }"
      )

      return JSON.parse( response.body )
    end

    # Compare a list of Person models with an API list call response holding
    # a list of Person resource representations, expecting each to match.
    #
    # +resources+:: The result from an API list call, complete with '_data'
    #               top-level key.
    # +models+::    A list of Person model instances, in the expected order.
    #
    def compare_lists( resources, *models )
      models.each_with_index do | model, index |
        resource = resources[ '_data' ][ index ]

        expect( model.name                  ).to eq( resource[ 'name'          ] )
        expect( model.date_of_birth.iso8601 ).to eq( resource[ 'date_of_birth' ] )
      end
    end

    it 'lists all' do
      result = do_list()
      compare_lists( result, @p4, @p3, @p2, @p1 )
    end

    it 'finds "alices"' do
      result = do_list( :partial_name => 'alice' )
      compare_lists( result, @p2, @p1 )
    end

    it 'finds names containing "E"' do
      result = do_list( :partial_name => 'E' )
      compare_lists( result, @p3, @p2, @p1 )
    end

    it 'finds people born in 1975' do
      result = do_list( :birth_year => '1975' )
      compare_lists( result, @p3, @p1 )
    end

    it 'finds "alices" born in 1975' do
      result = do_list( :partial_name => 'alice', :birth_year => '1975' )
      compare_lists( result, @p1 )
    end
  end
end
