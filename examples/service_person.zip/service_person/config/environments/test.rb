puts "Loading testing environment"

# Add environment-specific configuration here. E.g.:
#
# Service.config.foo = "bar"
